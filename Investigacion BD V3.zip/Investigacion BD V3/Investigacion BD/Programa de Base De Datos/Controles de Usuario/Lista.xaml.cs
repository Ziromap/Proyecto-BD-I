﻿using System;
using Programa_de_Base_De_Datos.Ventanas;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Programa_de_Base_De_Datos.Clases;

namespace Programa_de_Base_De_Datos.Controles_de_Usuario
{
    /// <summary>
    /// Lógica de interacción para Lista.xaml
    /// </summary>
    public partial class Lista : UserControl
    {
        private IniciarSesion iniciarSesion;
        public Lista(IniciarSesion iSesion)
        {
            iniciarSesion = iSesion;
            InitializeComponent();
            ActualizarTabla();
        }

        public void ActualizarTabla()
        {
            ListaEstudiantes.ItemsSource = Estudiante.Listar(iniciarSesion).DefaultView;
        }

        private Estudiante getSelectedRow()
        {            
            if ((ListaEstudiantes.SelectedItem as DataRowView) == null) return null;
            DataRow row = (ListaEstudiantes.SelectedItem as DataRowView).Row;
            return new Estudiante()
            {
                Nombre = (string)row[0],
                Apellido = (string)row[1],
                Edad = (int)row[2],
                Carnet = (string)row[3],
                Telefono = (int)row[4],
                Correo = (string)row[5]
            }; 
        }

        private void Eliminar_Click(object sender, RoutedEventArgs e)
        {
            Estudiante est = getSelectedRow();
            if(est != null) 
            {
                try
                {
                    Estudiante.Eliminar(est);
                }
                catch (SqlException)
                {
                    
                }
            }
            
            ActualizarTabla();
        }

        private void Actualizar_Click(object sender, RoutedEventArgs e)
        {
            Estudiante est = getSelectedRow();
            if (est != null) 
            {
                try
                {
                    Estudiante.Actualizar(est);
                }
                catch (SqlException)
                {
                    
                }
            }
            ActualizarTabla();
        }

        private void Buscar_Click(object sender, RoutedEventArgs e)
        {
            ListaEstudiantes.ItemsSource = Estudiante.Buscar(txtBuscar.Text,iniciarSesion).DefaultView; 
        }

        private void UpdateControl_Click(object sender, RoutedEventArgs e)
        {
            ActualizarTabla();
        }
    }
}
