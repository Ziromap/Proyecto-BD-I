﻿using Programa_de_Base_De_Datos.Clases;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Programa_de_Base_De_Datos.Controles_de_Usuario
{
    /// <summary>
    /// Lógica de interacción para Agregar.xaml
    /// </summary>
    public partial class Agregar : UserControl
    {
        private IniciarSesion iniciarSesion;
        public Agregar(IniciarSesion iSesion)
        {
            iniciarSesion = iSesion;
            InitializeComponent();
        }

        private void BtnAgregar_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Estudiante.Insertar(new Estudiante(txtNombres.Text, txtApellidos.Text, int.Parse(txtEdad.Text), txtCarnet.Text, int.Parse(txtTelefono.Text), txtCorreo.Text), iniciarSesion);
            }
            catch (SqlException)
            {
                MessageBox.Show("Ingrese todos los datos, por favor");
            }
            catch (SystemException ex) when (ex is FormatException || ex is OverflowException)
            {
                MessageBox.Show("Ingrese todos los datos, por favor");
            }
        }
    }
}
