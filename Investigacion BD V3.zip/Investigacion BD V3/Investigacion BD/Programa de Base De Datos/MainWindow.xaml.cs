﻿using Programa_de_Base_De_Datos.Ventanas;
using Programa_de_Base_De_Datos.Controles_de_Usuario;
using Programa_de_Base_De_Datos.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace Programa_de_Base_De_Datos
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public IniciarSesion iniciarSesion;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonPopUpLogout_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void ButtonOpenMenu_Click(object sender, RoutedEventArgs e)
        {
            ButtonOpenMenu.Visibility = Visibility.Collapsed;
            ButtonCloseMenu.Visibility = Visibility.Visible;
        }

        private void ButtonCloseMenu_Click(object sender, RoutedEventArgs e)
        {
            ButtonOpenMenu.Visibility = Visibility.Visible;
            ButtonCloseMenu.Visibility = Visibility.Collapsed;
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void BtnInfo_Click(object sender, RoutedEventArgs e)
        {
            Info info = new Info() { Owner = this};
            info.ShowDialog();
        }

        private void Agregar_Click(object sender, RoutedEventArgs e)
        {
            Agregar add = new Agregar(iniciarSesion);
            GridWork.Children.Clear();
            GridWork.Children.Add(add);
        }

        private void Mostrar_Click(object sender, RoutedEventArgs e)
        {
            Lista show = new Lista(iniciarSesion);
            GridWork.Children.Clear();
            GridWork.Children.Add(show);
        }

        private void Cerrar_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
