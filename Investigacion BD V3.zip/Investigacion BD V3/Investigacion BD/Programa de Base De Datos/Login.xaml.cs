﻿using System;
using Programa_de_Base_De_Datos.Clases;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace Programa_de_Base_De_Datos.Ventanas
{
    /// <summary>
    /// Lógica de interacción para Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public IniciarSesion GetLogin{ set; get; }
        public Login()
        {
            InitializeComponent();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Cerrar_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
            
        }

        private void Iniciar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IniciarSesion iSesion = new IniciarSesion(txtUsuario.Text, txtContraseña.Password);
                if (IniciarSesion.ValidarUsuario(iSesion).Rows.Count != 0) 
                {
                    GetLogin = iSesion;
                    DialogResult = true;
                    this.Close();
                }
            }
            catch (SqlException)
            {
                //Codigo por si la conexion esta choca
            }
        }
    }
}
