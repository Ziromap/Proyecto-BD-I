﻿using System;
using Programa_de_Base_De_Datos.Ventanas;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_de_Base_De_Datos.Clases
{
    public class Estudiante
    {
        public Estudiante() { }

        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
        public string Carnet { get; set; }
        public int Telefono { get; set; }
        public string Correo { get; set; }

        public Estudiante(string nombre, string apellido, int edad, string carnet, int telefono, string correo)
        {
            Nombre = nombre;
            Apellido = apellido;
            Edad = edad;
            Carnet = carnet;
            Telefono = telefono;
            Correo = correo;
        }

        public static void Insertar(Estudiante estudiante, IniciarSesion iSesion)
        {
            try
            {
                Conexion.ejecutarQuery($"EXEC insertar '{estudiante.Nombre}', '{estudiante.Apellido}', {estudiante.Edad}, '{estudiante.Carnet}', {estudiante.Telefono}, '{estudiante.Correo}', '{iSesion.Usuario}'");
            }catch (SqlException)
            {
                throw;
            }
        }

        public static void Actualizar(Estudiante estudiante)
        {
            try { 
                Conexion.ejecutarQuery($"EXEC actualizar '{estudiante.Nombre}', '{estudiante.Apellido}', {estudiante.Edad}, '{estudiante.Carnet}', {estudiante.Telefono}, '{estudiante.Correo}'");
            }catch (SqlException)
            {
                throw;
            }
        }   

        public static DataTable Listar(IniciarSesion iSesion)
        {
            return Conexion.ejecutarQuery($"EXEC listar {iSesion.Usuario}", "estudiante");
        }

        public static void Eliminar(Estudiante estudiante)
        {
            try
            {
                Conexion.ejecutarQuery($"EXEC eliminar '{estudiante.Carnet}'");
            }
            catch (SqlException)
            {
                throw;
            }
        }

        public static DataTable Buscar(string carnet, IniciarSesion iSesion)
        {
            if (carnet == "") { return Listar(iSesion); } 
            try
            {
                return Conexion.ejecutarQuery($"EXEC buscar '{carnet}', '{iSesion.Usuario}'", "estudiante");
            }
            catch(SqlException)
            {
                return Listar(iSesion);
            }
            
        }
    }
}
