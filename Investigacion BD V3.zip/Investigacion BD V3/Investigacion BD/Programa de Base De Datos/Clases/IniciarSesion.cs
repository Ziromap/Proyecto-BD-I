﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_de_Base_De_Datos.Clases
{
    public class IniciarSesion
    {
        public IniciarSesion() { }

        public string Usuario { get; set; }
        public string Contraseña { get; set; }

        public IniciarSesion(string usuario, string contraseña)
        {
            Usuario = usuario;
            Contraseña = contraseña;
        }

        // Usarlo para registrar un usuario en la base de datos
        public static void RegistrarUsuario(IniciarSesion iniciar)
        {
            try
            {
                Conexion.ejecutarQuery($"EXEC registrarUsuario '{iniciar.Usuario}', '{iniciar.Contraseña}'");
            }
            catch (SqlException)
            {
                throw;
            }
        }

        //Usarlo para validar usuario
        public static DataTable ValidarUsuario(IniciarSesion iniciar)
        {
            try
            {
               return Conexion.ejecutarQuery($"EXEC validarUsuario '{iniciar.Usuario}', '{iniciar.Contraseña}'","iniciarSesion");
            }
            catch (SqlException)
            {
                throw;
            }
        }
    }
}
