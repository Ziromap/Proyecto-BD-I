﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Programa_de_Base_De_Datos.Clases
{
    public static class Conexion
    {
        //Nombre del Servidor | Cambiarlo ya que cada pc tiene un nombre de servidor diferente BYBL4DERXX_LAPT
        private static readonly string acServer = "Localhost";
        //String de conexion
        private static readonly string acConnectionString = $"Server={acServer};Database=tarea1;Integrated Security = true";

        //Pasa un query por la conexion, la ejecuta y devuelve un DataTable 
        public static DataTable ejecutarQuery(string command, string nameTable = "") 
        {
            using (SqlConnection sqlc = new SqlConnection(acConnectionString))
            {
                SqlCommand sqlcon = new SqlCommand(command, sqlc);
                SqlDataAdapter sqldata = new SqlDataAdapter(sqlcon);
                DataTable dt = new DataTable(nameTable);

                try { sqldata.Fill(dt); } catch (SqlException ex) { throw ex; }

                // Si no se especifica el nombre de la tabla no devuelve.
                return ((nameTable == "") ? null : dt);
            }
        }

    }
}
