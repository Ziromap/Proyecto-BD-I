﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Programa_de_Base_De_Datos.Clases;
using Programa_de_Base_De_Datos.Ventanas;

namespace Programa_de_Base_De_Datos
{
    /// <summary>
    /// Lógica de interacción para App.xaml
    /// </summary>
    public partial class App : Application
    {

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            Login login = new Login();
            if ((bool)login.ShowDialog()) new MainWindow() { iniciarSesion = login.GetLogin }.ShowDialog();
        }
    }
}
