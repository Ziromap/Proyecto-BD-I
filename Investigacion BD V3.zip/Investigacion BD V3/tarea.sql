create database tarea1;

GO
use tarea1;
/*
Select * From estudiante
Select * From iniciarSesion
*/
create table iniciarSesion(
Usuario nvarchar(50) not null,
Contrasena nvarchar(50) not null,
Primary Key (Usuario)
)

create table estudiante(
nombre nvarchar(20) not null,
apellido nvarchar(20) not null,
edad int not null,
carnet nvarchar(15) unique not null,
telefono int not null,
correo nvarchar(35) not null,
usuario nvarchar(50) not null,
foreign key (usuario) references iniciarSesion(Usuario)
)


--Registrar usuario en la base de datos
GO
create procedure registrarUsuario
@usuario nvarchar(50),
@contrasena nvarchar(50)
as
begin
	insert into iniciarSesion(Usuario,Contrasena) values (@usuario,@contrasena)
end

--Validar un usuario
GO
create procedure validarUsuario
@usuario nvarchar(50),
@contrasena nvarchar(50)
as
begin
	Select * From iniciarSesion where (usuario = @usuario and contrasena = @contrasena)
end
--Procedimiento para insertar o guardar estudiantes en una tabla
GO
create procedure insertar
@nombre nvarchar(15),
@apellido nvarchar(15),
@edad int,
@carnet nvarchar(10),
@tel int,
@correo nvarchar(35),
@usuario nvarchar(50)
as
begin
insert into estudiante (nombre,apellido,edad,carnet,telefono,correo,usuario) values (@nombre,@apellido,@edad,@carnet,@tel,@correo,@usuario)

end
--Procedimiento para actualizar
GO
create procedure actualizar
@nombre nvarchar(15),
@apellido nvarchar(15),
@edad int,
@carnet nvarchar(10),
@tel int,
@correo nvarchar(35)
as 

begin

update estudiante 
set nombre = @nombre,
apellido = @apellido,
edad = @edad,
telefono = @tel,
correo = @correo
where carnet = @carnet

end
--Procedimiento para eliminar
GO
create procedure eliminar
@carnet nvarchar(10)
as 
begin

delete from estudiante 
where carnet = @carnet

end
--Procedimiento para buscar
GO
create procedure listar
@usuario nvarchar(50)
as
begin
select * from estudiante where usuario = @usuario;
end
--Procedimiento para buscar a estudiantes por carnet
GO
create procedure buscar
@carnet nvarchar(10),
@usuario nvarchar(50)
as

begin

select * from estudiante
where carnet = @carnet and usuario = @usuario
end

GO
exec registrarUsuario 'admin','1234'
--drop procedure insertar
--drop procedure actualizar
--drop procedure eliminar
--drop procedure listar
--drop procedure buscar
